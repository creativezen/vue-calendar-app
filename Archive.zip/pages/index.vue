<script setup>
  useHead({
    titleTemplate: 'Главная | %s',
  })
</script>

<template>
  <Calendar />
</template>
