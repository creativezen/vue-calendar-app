<script setup></script>

<template>
  <section class="section">
    <div class="container">
      <div class="section__header">
        <h1 class="title">Авторизация</h1>
      </div>
      <div class="section__body"></div>
    </div>
  </section>
</template>
