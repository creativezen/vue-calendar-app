<template>
  <section class="section">
    <div class="container">
      <div class="section__header">
        <h2 class="title">Контакты</h2>
      </div>
      <div class="section__body"></div>
    </div>
  </section>
</template>
