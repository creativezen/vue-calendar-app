<template>
  <main class="main">
    <slot />
  </main>
</template>
