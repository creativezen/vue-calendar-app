<template>
  <footer class="footer">
    <div class="container">
      <div class="footer__links">
        <ul>
          <li><NuxtLink to="/">Главная</NuxtLink></li>
          <li><NuxtLink to="/contacts">Контакты</NuxtLink></li>
        </ul>
      </div>
    </div>
  </footer>
</template>
